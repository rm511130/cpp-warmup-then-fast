{  
  "service" : {  
    "api" : "http",
    "port" : 8888
  },  
  "logging" : {
    "level" : "debug"
  }
}  
